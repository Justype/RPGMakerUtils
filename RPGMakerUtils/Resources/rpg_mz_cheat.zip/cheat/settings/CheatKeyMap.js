export default {
    toggleCheatModal: 'ctrl c'
}
