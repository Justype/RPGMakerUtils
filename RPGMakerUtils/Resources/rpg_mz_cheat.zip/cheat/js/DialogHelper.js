export class ConfirmDialog {
    static show (option) {

    }

    static close () {

    }
}
